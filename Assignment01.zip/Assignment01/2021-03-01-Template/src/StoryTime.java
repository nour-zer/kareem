
public class StoryTime {
	public static void main(String[] args) {
		// Creating & Initializing GTerm settings.
		GTerm gt = new GTerm(1400, 1000);

		// Setting font size to 14
		gt.setFontSize(18);
		// Placing content in the top centre
		gt.setXY(100, 0);
		// Prompting child to input their name & storing their name as a string in a
		// variable called name
		String name = gt.getInputString("Hello there :) What is your name?");
		// Prompting child to input their gender 'm' or 'f' & storing their name as a
		// character in a variable called gender.Also if the child inputs a word we
		// extract the first character.
		char gender = gt.getInputString("Nice to meet you " + name
				+ " My name is Joy, I'm your interactive story teller.\nCan you please tell me what your gender is by typing either 'm' or 'f'?")
				.charAt(0);
		// Indefinite loop that checks the child has put either m/f/M/F ie) correct
		// gender nothing else
		while (gender != 'm' && gender != 'f' && gender != 'M' && gender != 'F') {
			gender = gt
					.getInputString(
							"Oops!! Looks like you have entered the wrong gender. Please type either 'm' or 'f'")
					.charAt(0);
		}

		// Declaring a string variable that will be used in the subsequent if statement
		// block. This variable will either be boy or girl.
		String userGender;
		// if statement that will dictate how we address the child ie) boy or girl,
		// based on the inputed gender & change the "Theme" of GT into either masculine
		// or feminine
		if (gender == 'm' || gender == 'M') {
			userGender = "boy";
			gt.setBackgroundColor(102, 78, 255);// Setting terminal background colour to blue
			gt.setFontColor(255, 255, 255);// Setting terminal text font to white
//	        gt.addImageIcon("https://github.com/nour-zer/assessment1/blob/main/images/nour01.jpg");

		} else {

			userGender = "girl";
			gt.setBackgroundColor(255, 153, 255);// Setting terminal background colour to pink
			gt.setFontColor(51, 51, 0);// Setting terminal text font to goldy colour
		}
		// Embeded values are used to greet child appropriately & prompt them to enter
		// their age which is stored as an integer type in variabled named age
		int age = Integer.parseInt(gt.getInputString("Great work " + name + " You look like a nice cute " + userGender
				+ " :)\nCan you please tell me your age?"));

		// Indefinite loop that checks the child has put in an appropriate age which has
		// to be a positive whole number or less than 18 otherwise they will be
		// considered an adult
		while (age < 0 || age > 17) {
			if (age > 17)
				age = Integer.parseInt(gt.getInputString(
						"Hmmm I'm sorry this story is not for adults. It is only for children.\nPlease input age less than 18"));
			else
				age = Integer.parseInt(gt.getInputString(
						"Woops :( You did not input a valid age. Please type a whole number greater than 0"));
		}

		// Declaring a counter variable to be used in subsequent loop

		int i = 1;
	    gt.println(gt.getFilePath());
		while (i <= age) {
			if (userGender == "boy") {
				if (i == 1) {
					gt.println(name + " is a " + age
							+ " year old boy who loves to play basketball.\n One day his friend Adam challenged him to a shooting contest and he said to "
							+ name + " 'Can you hit " + age
							+ " shots from the freethrow line which is the same number as your age?'.\n So " + name
							+ " went up to the freethrow and started to shoot...\n\n");
				}

				gt.println(name + " attempted basketball shot number " + i + " out of a total " + age + " shots\n");
//		gt.addImageIcon(shooting.jpg);

			} else {
				if (i == 1) {
					gt.println(name + " is a " + age
							+ " year old girl who loves to play skipping rope.\n One day her friend Nour challenged her to a shooting contest and she said to "
							+ name + " 'Can you skip the rope none stop " + age
							+ " times which is the same number as your age?'.\n So " + name
							+ " grabbed the skipping rope and started skipping...\n\n");
				}

				gt.println(name + " skipped the rope " + i + " out of a total " + age + " skips\n");

			}

			i++;
		}
//		gt.showErrorDialog("test")
//		showErrorDialog, showMessageDialog, showWarningDialog and close
	}
}
