public class Datatypes {
	public static void main(String[] args) {
		GTerm gt = new GTerm(700, 400);
		
		//Declaring string variable which has a value based on user input
		String sequenceOfChars = gt.getInputString("Please input a STRING:");
		
		//Declaring integer variable which has a value based on user input that is being converted 
		//from string to integer
        int wholeNumber = Integer.parseInt(gt.getInputString("Please input a WHOLE NUMBER:"));
      
        //Declaring char variable which has a value based on user input that is being converted 
        //from string to character. We are extracting only the first character of the string
        char singleCharacter = gt.getInputString("Please input a CHARACTER:").charAt(0);
        
        //Declaring double/decimal point variable which has a value based on user input 
        //that is being converted from string to double.
        double decimalNumber = Double.parseDouble(gt.getInputString("Please input a DECIMAL NUMBER:"));
        
        //Declaring Boolean variable which has a value based on user input that is being converted 
        //from string to Booalean (True if user type true, False if user type anything else).
        boolean booleanVar = Boolean.parseBoolean(gt.getInputString("Please input a Boolean:"));
        
        //Checking if conversion from string tp integer is working & user type number greater than 0
        if (wholeNumber > 0 ) {
    	   
    	   gt.println("Congratulations you have successfully converted a string into an integer");
       }
	   
        //Checking if conversion from string to character is working & user typed something beginning with
        // character 'H'
        if (singleCharacter == 'H' ) {
    	   
	       gt.println("Congratulations you have successfully converted a string into a character 'H'");
       }
       
       //Checking if conversion from string to decimal number is working & user typed a number greater than
       // 0.1
       if (decimalNumber > 0.1 ) {
    	   
    	   gt.println("Congratulations you have successfully converted a string into decimal number");
       }
	
       //Checking if conversion from string to boolean is working & user typed a string "TRUE" otherwise
       // booleanVar will default to false
       
       if (booleanVar ) {
    	   
	       gt.println("Congrats!!! string that spelt TRUE & was succsessfully converted to Boolean");
       } 
       else {
    	   gt.println("Congrats!!! was succsessfully converted to Boolean but wasn't TRUE");
       }
	}
}
