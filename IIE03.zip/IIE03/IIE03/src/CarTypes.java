public class CarTypes {
	public static void main(String[] args) {
		GTerm gt = new GTerm(700, 400);

		// Declaring string variable named answer which captures the entire user input
		// with one prompt
		String answer = gt.getInputString(
				"Enter car type made up of the following fields & separated by ':'\n Make:Year of Manufacture:In Stock?:Weight:Series");

		// Declaring & creating a String array which will be used to store all the
		// string elements which have been split into 5 string elements
		String[] elements = answer.split(":");

		// Assigning the first element of the string array to a string variable called
		// make
		String make = elements[0];

		// Converting the 2nd element of the string array to an integer & assigning it
		// to an integer variable called yearofManufacture
		int yearOfManufacture = Integer.parseInt(elements[1]);

		// Converting the 3nd element of the string array to a boolean & assigning it to
		// an boolean variable called inStock
		boolean inStock = Boolean.parseBoolean(elements[2]);

		// Converting the 4th element of the string array to a double/decimal number &
		// assigning it to an double variable called weight
		double weight = Double.parseDouble(elements[3]);

		// Extracting the first character the 5th element of the string array &
		// assigning it to an character variable called series
		char series = elements[4].charAt(0);

		// Printing out a confirmation of what the user typed in in a list format.
		gt.println("Confirming your entry as follows:\nMAKE: " + make + "\nYear Of Manufacture: " + elements[1]
				+ "\nIn Stock: " + elements[2] + "\nWeight: " + elements[3] + "\nSeries: " + series + "\n\n");

		if (elements[4].length() > 1 && inStock == true) {

			gt.println("The " + make + " is in stock, however the series entered '" + elements[4]
					+ "' is incorrect & it must be a single character not a string.\n We have extracted the first character '"
					+ series + "' only\n\n");
		}

		if (weight > 100) {
			if (yearOfManufacture < 2000) {
				gt.println("The " + make + " you have entered is considered too heavy & too old with a weight of "
						+ elements[3] + " kg & year of manufacture " + elements[1] + ".\n");
			}
		}
	}
}
